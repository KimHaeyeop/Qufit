-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance_game`
--

DROP TABLE IF EXISTS `balance_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_game` (
  `balance_game_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `scenario1` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `scenario2` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`balance_game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_game`
--

LOCK TABLES `balance_game` WRITE;
/*!40000 ALTER TABLE `balance_game` DISABLE KEYS */;
INSERT INTO `balance_game` VALUES (1,'둘 중 더 나은 선택은?','싫어하는 사람과 10억 나누기','그냥 1억만 받기'),(2,'술 마시고 필름 끊긴 후 다음날 통화내역에','전남친, 전여친 전화 30통','직장 상사와 통화 내역 5분'),(3,'둘 중 더 싫은상황은?','내가 절친 동생 만나기','동생이 내 절친 만나기'),(4,'더 합리적인 선택은?','당장에 5억 받기','50살에 50억 받기'),(5,'더 합리적인 선택은?','8시 출근 / 17시 퇴근','11시 출근 / 20시 퇴근'),(6,'더 합리적인 선택은?','주 3회 최소 1시간 야근','매일 퇴근 후 간단한 업무 연락받기(ex. 이 파일 어디에 있어요?)'),(7,'매일','불편한 직장 상사와 한우 먹기','혼자 or 친한 동료와 컵라면 먹기'),(8,'둘 중 누구랑 사귈거야?(무조건 사귀어야 함)','짠돌이 애인','과소비 애인'),(9,'더 창피한 상황은?','단톡방 고백','길거리 고백'),(10,'바람 피우고','평생 숨기는 애인','자백하고 용서 구하는 애인'),(11,'더 나은 것은?','내가 좋아하는 사람과 결혼하기','나를 좋아하는 사람과 결혼하기'),(12,'더 싫은 배우자는?','취미 생활에 용돈 탕진하는 배우자','취미 생활 없이 나한테까지 절약 강요하는 배우자'),(13,'내가 만든 맛없는 음식','맛있게 먹어주지만 요리 1도 안하는 배우자','맛 없다고 구박하고 해먹는 배우자'),(14,'더 싫은 친구는?','밥 먹고 카페만 가는 친구','밥 안먹고 술집만 가는 친구'),(15,'더 싫은 상황은?','일주일 머리 감기 불가','일주일 양치질 불가'),(16,'더 나은 것은?','이상적인 얼굴로 살기','50억 받기'),(17,'둘 중 누구랑 사귈거야?(무조건 사귀어야 함)','학폭 가해자였던 애인','절도 전과 5건 있는 애인'),(18,'둘 중 누구랑 사귈거야?(무조건 사귀어야 함)','매일 약속 시간 1시간 늦는 애인(사과 안함)','1시간씩 빨리 오는 애인(1분이라도 늦으면 오래 기다렸다면서 극대노)'),(19,'둘 중 누가 나아?','하루에 열 번 넘게 삐지고 10분 만에 풀리는 애인','한 달에 한 번 삐지지만 풀리는 데 일주일 걸리는 애인'),(20,'둘 중 하나를 선택한다면?','매일 날 따라다니는 바퀴벌레 한 마리(죽일 수 없음)','집에 오면 부끄러워서 숨어버리는 바퀴벌레 백 마리'),(21,'둘 중 누구랑 사귈거야?(무조건 사귀어야 함)','친구 한명도 없어서 답장 엄청 빠른 애인','친구 너무 많아서 연락 안되는 애인'),(22,'둘 중 누구랑 사귈거야?(무조건 사귀어야 함)','내가 하는 말 하나하나 의미부여해서 혼자 섭섭해 하는 애인','내가 하는 말 한 귀로 흘려서 기억하는거 하나도 없는 애인'),(23,'둘 중 하나를 선택한다면?','전 애인이랑 비교하는 애인','전 애인이랑 비교되는 애인'),(24,'둘 중 하나를 선택한다면?','나 같은 자식 낳기','나 같은 부모에게 길러지기'),(25,'둘 중 하나를 선택한다면?','나랑 똑같은 사람과 연애하기','나랑 정반대인 사람과 연애하기'),(26,'더 싫은 상황은?','10년 지기 이성친구 1명 있는 애인','간간이 안부 묻는 이성친구 10명 있는 애인'),(27,'더 싫은 상황은?','똥 안먹었는데 먹었다고 소문나기','진짜 똥 먹고 아무도 모르기'),(28,'더 싫은 상황은?','애인이 다른 사람과 바람피우기','알고보니 내가 바람피운 상대'),(29,'더 배신감 느끼는 상황은?','숨겨진 자식이 있는 애인','이혼 3번 한 애인'),(30,'더 싫은 상황은?','마음에 안 드는 물건 선물하고 사용 강요하는 애인','내가 사준 선물 몰래 중고나라에 파는 애인'),(31,'더 나은 것은?','방귀 뀔 때마다 썸 타는 사람에게 \"OO님이 방귀를 뀌셨습니다. 50 데시벨.\" 문자가기','전 애인 생각할 때마다 SNS에 \"OO님이 지금 전 애인을 생각하고 있습니다\" 게시물 올라가기'),(32,'더 갖고 싶은 것은?','천재적인 두뇌','몸매와 얼굴'),(33,'','콧털 긴 애인','겨털 긴 애인'),(34,'','100억 받고 50살까지 살기','그냥 100살까지 살기'),(35,'','회 못먹는 친구랑 바닷가 놀러가기','노래 안하는 친구랑 노래방 가기');
/*!40000 ALTER TABLE `balance_game` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:41
