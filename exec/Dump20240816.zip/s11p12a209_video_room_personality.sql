-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video_room_personality`
--

DROP TABLE IF EXISTS `video_room_personality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_room_personality` (
  `tag_id` bigint(20) DEFAULT NULL,
  `video_personality_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `video_room_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`video_personality_id`),
  KEY `FK7v7lljsybm0fv6t3lsbbu2er3` (`tag_id`),
  KEY `FK55u6h3mt38ug0t54tl9o0tnyb` (`video_room_id`),
  CONSTRAINT `FK55u6h3mt38ug0t54tl9o0tnyb` FOREIGN KEY (`video_room_id`) REFERENCES `video_room` (`video_room_id`),
  CONSTRAINT `FK7v7lljsybm0fv6t3lsbbu2er3` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_room_personality`
--

LOCK TABLES `video_room_personality` WRITE;
/*!40000 ALTER TABLE `video_room_personality` DISABLE KEYS */;
INSERT INTO `video_room_personality` VALUES (43,15,552),(43,16,569),(29,18,590),(52,19,590),(35,20,603),(54,24,663),(25,28,679),(27,29,679),(43,47,795),(34,59,824),(39,60,824),(33,61,824),(52,62,824),(47,63,824),(35,69,850),(41,70,863),(38,71,863),(21,74,877),(35,75,878),(33,76,879),(41,77,881),(43,78,888),(36,79,890),(22,80,892),(33,81,893),(49,82,912),(23,83,913),(43,84,920),(38,86,926),(31,87,976),(48,88,998),(36,89,998),(24,90,998);
/*!40000 ALTER TABLE `video_room_personality` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:42
