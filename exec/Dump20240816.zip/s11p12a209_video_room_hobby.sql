-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `video_room_hobby`
--

DROP TABLE IF EXISTS `video_room_hobby`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_room_hobby` (
  `tag_id` bigint(20) DEFAULT NULL,
  `video_hobby_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `video_room_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`video_hobby_id`),
  KEY `FKeimpypc3hygulmp37onttk60o` (`tag_id`),
  KEY `FKb4tbejsvdn94v3wglal8694l5` (`video_room_id`),
  CONSTRAINT `FKb4tbejsvdn94v3wglal8694l5` FOREIGN KEY (`video_room_id`) REFERENCES `video_room` (`video_room_id`),
  CONSTRAINT `FKeimpypc3hygulmp37onttk60o` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_room_hobby`
--

LOCK TABLES `video_room_hobby` WRITE;
/*!40000 ALTER TABLE `video_room_hobby` DISABLE KEYS */;
INSERT INTO `video_room_hobby` VALUES (62,29,524),(59,31,539),(71,32,539),(76,33,539),(77,34,539),(70,35,546),(70,36,547),(70,37,548),(63,38,617),(63,40,660),(79,55,824),(78,56,824),(65,57,824),(64,58,824),(69,59,824),(59,62,844),(68,63,859),(68,65,862),(58,70,880),(59,71,880),(71,72,889),(77,73,895),(72,74,897),(71,75,912),(71,76,916),(78,77,916),(73,78,918),(81,79,918),(84,81,932),(57,82,941),(61,83,941),(77,85,956),(61,86,964),(76,87,967),(108,88,970),(93,89,971),(94,90,974),(68,91,975),(60,92,985),(61,93,985),(62,94,985),(63,95,985),(69,96,992),(62,97,992),(94,98,998),(88,99,998),(80,100,998),(59,101,1000),(91,102,1000);
/*!40000 ALTER TABLE `video_room_hobby` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:39
