-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance_game_choice`
--

DROP TABLE IF EXISTS `balance_game_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balance_game_choice` (
  `choice_num` int(11) NOT NULL CHECK (`choice_num` <= 2 and `choice_num` >= 0),
  `balance_game` bigint(20) DEFAULT NULL,
  `balance_game_choice_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member` bigint(20) DEFAULT NULL,
  `video_room` bigint(20) DEFAULT NULL,
  `choice_content` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`balance_game_choice_id`),
  KEY `FK9qnr03qc7ic6k9u8xgppj83vl` (`balance_game`),
  KEY `FKodpqdhdxpjnduur2kifkifs3w` (`member`),
  KEY `FKgxpdhegvt0dwj44k8yhkgssv9` (`video_room`),
  CONSTRAINT `FK9qnr03qc7ic6k9u8xgppj83vl` FOREIGN KEY (`balance_game`) REFERENCES `balance_game` (`balance_game_id`),
  CONSTRAINT `FKgxpdhegvt0dwj44k8yhkgssv9` FOREIGN KEY (`video_room`) REFERENCES `video_room` (`video_room_id`),
  CONSTRAINT `FKodpqdhdxpjnduur2kifkifs3w` FOREIGN KEY (`member`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance_game_choice`
--

LOCK TABLES `balance_game_choice` WRITE;
/*!40000 ALTER TABLE `balance_game_choice` DISABLE KEYS */;
INSERT INTO `balance_game_choice` VALUES (2,2,73,2,806,'직장 상사와 통화 내역 5분'),(1,2,74,3,806,'전남친, 전여친 전화 30통'),(2,29,75,3,806,'이혼 3번 한 애인'),(2,29,76,2,806,'이혼 3번 한 애인'),(1,1,77,2,806,'싫어하는 사람과 10억 나누기'),(2,1,78,3,806,'그냥 1억만 받기'),(1,16,79,3,812,'이상적인 얼굴로 살기'),(2,16,80,2,812,'50억 받기'),(1,11,81,3,812,'내가 좋아하는 사람과 결혼하기'),(1,11,82,2,812,'내가 좋아하는 사람과 결혼하기'),(2,8,83,3,812,'과소비 애인'),(1,8,84,2,812,'짠돌이 애인'),(1,5,85,3,812,'8시 출근 / 17시 퇴근'),(2,5,86,2,812,'11시 출근 / 20시 퇴근'),(1,30,87,3,813,'마음에 안 드는 물건 선물하고 사용 강요하는 애인'),(2,30,88,2,813,'내가 사준 선물 몰래 중고나라에 파는 애인'),(2,19,89,3,813,'한 달에 한 번 삐지지만 풀리는 데 일주일 걸리는 애인'),(1,19,90,2,813,'하루에 열 번 넘게 삐지고 10분 만에 풀리는 애인'),(1,12,91,2,813,'취미 생활에 용돈 탕진하는 배우자'),(2,12,92,3,813,'취미 생활 없이 나한테까지 절약 강요하는 배우자'),(2,26,93,3,815,'간간이 안부 묻는 이성친구 10명 있는 애인'),(1,26,94,2,815,'10년 지기 이성친구 1명 있는 애인'),(2,14,95,3,815,'밥 안먹고 술집만 가는 친구'),(2,14,96,2,815,'밥 안먹고 술집만 가는 친구'),(1,34,97,2,815,'100억 받고 50살까지 살기'),(2,34,98,3,815,'그냥 100살까지 살기'),(2,29,99,2,817,'이혼 3번 한 애인'),(1,29,100,3,817,'숨겨진 자식이 있는 애인'),(1,29,101,3,825,'숨겨진 자식이 있는 애인'),(2,29,102,2,825,'이혼 3번 한 애인'),(1,19,103,2,825,'하루에 열 번 넘게 삐지고 10분 만에 풀리는 애인'),(2,19,104,3,825,'한 달에 한 번 삐지지만 풀리는 데 일주일 걸리는 애인'),(1,17,105,2,825,'학폭 가해자였던 애인'),(2,17,106,3,825,'절도 전과 5건 있는 애인'),(2,3,107,3,827,'동생이 내 절친 만나기'),(1,3,108,2,827,'내가 절친 동생 만나기'),(2,2,109,3,827,'직장 상사와 통화 내역 5분'),(2,2,110,2,827,'직장 상사와 통화 내역 5분'),(1,18,111,2,829,'매일 약속 시간 1시간 늦는 애인(사과 안함)'),(2,18,112,3,829,'1시간씩 빨리 오는 애인(1분이라도 늦으면 오래 기다렸다면서 극대노)'),(2,1,113,2,829,'그냥 1억만 받기'),(1,1,114,3,829,'싫어하는 사람과 10억 나누기'),(1,18,115,2,838,'매일 약속 시간 1시간 늦는 애인(사과 안함)'),(2,18,116,3,838,'1시간씩 빨리 오는 애인(1분이라도 늦으면 오래 기다렸다면서 극대노)'),(2,32,117,2,838,'몸매와 얼굴'),(2,32,118,3,838,'몸매와 얼굴'),(1,33,119,2,838,'콧털 긴 애인'),(1,33,120,3,838,'콧털 긴 애인'),(1,29,121,65,863,'숨겨진 자식이 있는 애인'),(1,29,122,67,863,'숨겨진 자식이 있는 애인'),(2,29,123,64,863,'이혼 3번 한 애인'),(2,29,124,66,880,'이혼 3번 한 애인'),(2,29,125,65,880,'이혼 3번 한 애인'),(1,9,126,3,905,'단톡방 고백'),(2,9,127,65,905,'길거리 고백'),(0,30,128,2,928,''),(0,8,129,3,932,''),(0,8,130,4,932,''),(1,27,131,3,943,'똥 안먹었는데 먹었다고 소문나기'),(2,24,132,2,955,'나 같은 부모에게 길러지기'),(1,24,133,3,955,'나 같은 자식 낳기'),(2,32,134,2,956,'몸매와 얼굴'),(1,32,135,3,956,'천재적인 두뇌'),(2,6,136,4,981,'매일 퇴근 후 간단한 업무 연락받기(ex. 이 파일 어디에 있어요?)'),(0,6,137,3,981,''),(0,1,138,2,981,''),(0,1,139,5,981,''),(2,5,140,3,990,'11시 출근 / 20시 퇴근'),(1,5,141,2,990,'8시 출근 / 17시 퇴근');
/*!40000 ALTER TABLE `balance_game_choice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:46
