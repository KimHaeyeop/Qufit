-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `tag_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `tag_category` enum('HOBBY','MBTI','PERSONALITY') COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `UK1r1tyf6uga9k6jwdqnoqwtk2a` (`tag_name`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'none','MBTI'),(2,'INFP','MBTI'),(3,'ENFP','MBTI'),(4,'INTP','MBTI'),(5,'ENTP','MBTI'),(6,'INFJ','MBTI'),(7,'ENFJ','MBTI'),(8,'INTJ','MBTI'),(9,'ENTJ','MBTI'),(10,'ISFP','MBTI'),(11,'ESFP','MBTI'),(12,'ISTP','MBTI'),(13,'ESTP','MBTI'),(14,'ISFJ','MBTI'),(15,'ESFJ','MBTI'),(16,'ISTJ','MBTI'),(17,'ESTJ','MBTI'),(18,'긍정적인','PERSONALITY'),(19,'체계적인','PERSONALITY'),(20,'즉흥적인','PERSONALITY'),(21,'계획적인','PERSONALITY'),(22,'창의적인','PERSONALITY'),(23,'감성적인','PERSONALITY'),(24,'독립적인','PERSONALITY'),(25,'실질적인','PERSONALITY'),(26,'사교적인','PERSONALITY'),(27,'다정한','PERSONALITY'),(28,'신중한','PERSONALITY'),(29,'온화한','PERSONALITY'),(30,'과묵한','PERSONALITY'),(31,'상냥한','PERSONALITY'),(32,'솔직한','PERSONALITY'),(33,'적응을 잘하는','PERSONALITY'),(34,'표현을 잘하는','PERSONALITY'),(35,'배려를 잘하는','PERSONALITY'),(36,'경청을 잘하는','PERSONALITY'),(37,'상상력이 풍부한','PERSONALITY'),(38,'도전 정신이 뛰어난','PERSONALITY'),(39,'재치있는','PERSONALITY'),(40,'인내심 있는','PERSONALITY'),(41,'공감 능력이 뛰어난','PERSONALITY'),(42,'책임감 있는','PERSONALITY'),(43,'이해가 빠른','PERSONALITY'),(44,'규칙을 잘 지키는','PERSONALITY'),(45,'겁이 많은','PERSONALITY'),(46,'동물을 좋아하는','PERSONALITY'),(47,'세심한','PERSONALITY'),(48,'직감이 뛰어난','PERSONALITY'),(49,'자유로운','PERSONALITY'),(50,'활발한','PERSONALITY'),(51,'주도적인','PERSONALITY'),(52,'호기심 많은','PERSONALITY'),(53,'적극적인','PERSONALITY'),(54,'생각이 많은','PERSONALITY'),(55,'리액션이 많은','PERSONALITY'),(56,'진지한','PERSONALITY'),(57,'여행','HOBBY'),(58,'캠핑','HOBBY'),(59,'낚시','HOBBY'),(60,'게임','HOBBY'),(61,'보드게임','HOBBY'),(62,'방탈출','HOBBY'),(63,'추리게임','HOBBY'),(64,'쇼핑','HOBBY'),(65,'심리테스트','HOBBY'),(66,'사주/타로','HOBBY'),(67,'뜨개질','HOBBY'),(68,'재봉','HOBBY'),(69,'라탄 공예','HOBBY'),(70,'목공예','HOBBY'),(71,'가죽공예','HOBBY'),(72,'보석 십자수','HOBBY'),(73,'퍼즐','HOBBY'),(74,'요리','HOBBY'),(75,'베이킹','HOBBY'),(76,'홈카페','HOBBY'),(77,'칵테일','HOBBY'),(78,'인테리어','HOBBY'),(79,'독서','HOBBY'),(80,'자기개발','HOBBY'),(81,'프로그래밍','HOBBY'),(82,'블로그','HOBBY'),(83,'음악 감상','HOBBY'),(84,'코인노래방','HOBBY'),(85,'뮤지컬 관람','HOBBY'),(86,'전시회','HOBBY'),(87,'연극','HOBBY'),(88,'공연','HOBBY'),(89,'밴드','HOBBY'),(90,'영화보기','HOBBY'),(91,'드라마보기','HOBBY'),(92,'유튜브','HOBBY'),(93,'러닝','HOBBY'),(94,'배드민턴','HOBBY'),(95,'테니스','HOBBY'),(96,'수영','HOBBY'),(97,'요가','HOBBY'),(98,'필라테스','HOBBY'),(99,'등산','HOBBY'),(100,'산책','HOBBY'),(101,'홈트','HOBBY'),(102,'자전거','HOBBY'),(103,'골프','HOBBY'),(104,'폴댄스','HOBBY'),(105,'사진 촬영','HOBBY'),(106,'글쓰기','HOBBY'),(107,'캘리그래피','HOBBY'),(108,'드로잉','HOBBY'),(109,'수채화','HOBBY'),(110,'아크릴화','HOBBY'),(111,'오일파스텔','HOBBY'),(112,'디지털 드로잉','HOBBY'),(113,'레진공예','HOBBY'),(114,'영상편집','HOBBY'),(115,'포토샵','HOBBY'),(116,'디자인','HOBBY');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:40
