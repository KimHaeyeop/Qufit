-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a209
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `type_profiles`
--

DROP TABLE IF EXISTS `type_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `type_profiles` (
  `type_age_max` int(11) DEFAULT NULL,
  `type_age_min` int(11) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `type_profiles_id` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`type_profiles_id`),
  UNIQUE KEY `UKlm57a27rxyrurrtu13kgdhlk2` (`member_id`),
  CONSTRAINT `FKcrk1t5pw86eywiyximk7gp2o2` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_profiles`
--

LOCK TABLES `type_profiles` WRITE;
/*!40000 ALTER TABLE `type_profiles` DISABLE KEYS */;
INSERT INTO `type_profiles` VALUES (10,10,2,1),(10,10,3,2),(10,10,4,3),(10,10,5,4),(10,10,6,5),(10,10,7,6),(10,10,8,7),(10,10,9,8),(10,10,10,9),(10,10,11,10),(10,10,12,11),(10,10,13,12),(10,10,14,13),(10,10,15,14),(10,10,16,15),(10,10,17,16),(10,10,18,17),(10,10,19,18),(10,10,20,19),(10,10,21,20),(10,10,22,21),(10,10,23,22),(10,10,24,23),(10,10,25,24),(10,10,26,25),(10,10,27,26),(10,10,28,27),(10,10,29,28),(10,10,30,29),(10,10,31,30),(10,10,32,31),(10,10,33,32),(10,10,34,33),(10,10,35,34),(10,10,36,35),(10,10,37,36),(10,10,38,37),(10,10,39,38),(10,10,40,39),(10,10,41,40),(10,10,42,41),(10,10,43,42),(10,10,44,43),(10,10,45,44),(10,10,47,45),(10,10,48,46),(10,10,49,47),(10,10,50,48),(10,10,51,49),(10,10,52,50),(10,10,53,51),(10,10,54,52),(10,10,55,53),(10,10,56,54),(10,10,57,55),(10,10,58,56),(10,10,59,57),(10,10,60,58),(10,10,61,59),(10,10,62,60),(10,10,63,61),(4,0,64,62),(6,6,65,63),(10,10,66,64),(4,4,67,65),(10,10,68,66);
/*!40000 ALTER TABLE `type_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 11:33:45
